package com.example.javier.agenda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }




    public void registar(View view) {
        Intent nue = null;
        switch (view.getId())
        {
            case R.id.button8:
                nue = new Intent(MainActivity.this,Main2Activity.class);
                break;
            case R.id.button7:
                nue = new Intent(MainActivity.this,Main3Activity.class);
                break;

        }

        startActivity(nue);
    }
}
