package com.example.javier.agenda;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by javier on 12/03/18.
 */

public class Coneccion extends SQLiteOpenHelper {
    public static final  String Tabla="registrar";

    public static final  String camp_Nom="nombre";
    public static final  String camp_Apell="apellido";
    public static final  String camp_Dire="direc";
    public static final  String camp_Nume="nume";
    public static final  String camp_Core="core";

    public static final  String crear ="CREATE TABLE "+Tabla+" (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"+camp_Nom+" TEXT,"+camp_Apell+" TEXT,"+camp_Dire+" TEXT,"+camp_Nume+" INTERGER,"+camp_Core+" TEXT)";

    public Coneccion(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
    db.execSQL(crear);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    db.execSQL("DROP TABLE  IF EXISTS "+Tabla);
    onCreate(db);
    }
}
