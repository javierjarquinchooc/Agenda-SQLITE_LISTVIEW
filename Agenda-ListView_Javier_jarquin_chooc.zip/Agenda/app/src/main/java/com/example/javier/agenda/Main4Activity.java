package com.example.javier.agenda;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main4Activity extends AppCompatActivity {
    ListView lista;
    ArrayList<String> informacion;
    ArrayList<datos> datos;

    Coneccion co ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        lista=(ListView)findViewById(R.id.listaa);

      co  = new Coneccion(getApplicationContext(),"registrar",null,1);
        cons();
        ArrayAdapter AD = new ArrayAdapter(this,R.layout.support_simple_spinner_dropdown_item,informacion);
        lista.setAdapter(AD);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String IN ="ID : "+datos.get(i).getId()+"\n";

                IN+="Nombre : "+datos.get(i).getNo()+"\n";
                        IN+="Apellido : "+datos.get(i).getApe()+"\n";
                IN+="Direccion : "+datos.get(i).getDire()+"\n";
                        IN+="Numero : "+datos.get(i).getNume()+"\n";
                IN+="Correo : "+datos.get(i).getCore()+"\n";

                Toast.makeText(getApplicationContext(),IN,Toast.LENGTH_LONG).show();
            }
        });


    }

    private void cons() {
        SQLiteDatabase db = co.getReadableDatabase();
        datos nuevo=null;
       datos = new ArrayList<datos>();

        Cursor cor=db.rawQuery("SELECT * FROM "+co.Tabla,null);
        while (cor.moveToNext()){

            nuevo= new datos();
            nuevo.setId(cor.getString(0));
            nuevo.setNo(cor.getString(1));
            nuevo.setApe(cor.getString(2));
            nuevo.setDire(cor.getString(3));
            nuevo.setNume(cor.getInt(4));
            nuevo.setCore(cor.getString(5));
            datos.add(nuevo);
        }
        mostr();
    }

    private void mostr() {

        informacion = new ArrayList<String>();
        for (int i=0;i<datos.size();i++)
        {
            informacion.add(datos.get(i).getId()+".-"+datos.get(i).getNo()+" "+datos.get(i).getApe());


        }
    }
}
