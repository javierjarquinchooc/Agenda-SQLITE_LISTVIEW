package com.example.javier.agenda;



/**
 * Created by javier on 12/03/18.
 */

public class datos  {

private String id;
private String No;
private String ape;
private String dire;
private Integer Nume;
private  String Core;

    public datos(String id, String no, String ape, String dire, Integer nume, String core) {
        this.id = id;
        No = no;
        this.ape = ape;
        this.dire = dire;
        Nume = nume;
        Core = core;
    }
public datos(){}
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNo() {
        return No;
    }

    public void setNo(String no) {
        No = no;
    }

    public String getApe() {
        return ape;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public String getDire() {
        return dire;
    }

    public void setDire(String dire) {
        this.dire = dire;
    }

    public Integer getNume() {
        return Nume;
    }

    public void setNume(Integer nume) {
        Nume = nume;
    }

    public String getCore() {
        return Core;
    }

    public void setCore(String core) {
        Core = core;
    }

    public void setId(int anInt) {
    }
}
